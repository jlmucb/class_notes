//
//		Random Numbers
//


//  -----------------------------------------------------------------------------------------------------------


void InitX917(int j, unsigned* puSeed, unsigned* pState)
{
}


void X917NextState(unsigned* puSeed, unsigned* pState)
{
}



void InitFIPS186(int j, unsigned* puSeed, unsigned* pState)
{
}


void FIPS186NextState(unsigned* puSeed, unsigned* pState)
{
}

//  -----------------------------------------------------------------------------------------------------------


