#include <stdio.h>
#include <io.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <time.h>
#include <string.h>

#ifdef MSC
#include "disable.h"
#endif
#include "rng.h"
#include "jmbase64.h"
#include "tinystr.h"
#include "tinyxml.h"
#include "jlmUtil.h"


#define MAXKEYBASE64SIZE 2048
#define BASE64LINE       50



// ---------------------------------------------------------------------------------------


/*
 *  <ds:KeyInfo xmlns:ds="http://www.w3.org/2000/09/xmldsig#">
 *      <ds:KeyName> jlmkey1 </ds:KeyName>
 *      <ds:KeyType> aes128-ctr-raw </ds:KeyType>
 *      <ds:KeyValue> NLxqhCM= </ds:KeyValue>
 *      <ds:IV> IV-Value </ds:IV>
 *  </ds:KeyInfo>
 *
 *  <ds:KeyInfo xmlns:ds="http://www.w3.org/2000/09/xmldsig#">
 *      <ds:KeyName> jlmkey1 </ds:KeyName>
 *      <ds:KeyType> aes128-ctr-raw </ds:KeyType>
 *      <ds:RSAKeyValue>
 *          <ds:E> Value </ds:E>
 *          <ds:D> Value </ds:D>
 *          <ds:Modulus>
 *              xA7SEU+e0yQH5rm9kbCDN9o3aPIo7HbP7tX6WOocLZAtNfyxSZDU16ksL6W
 *          </ds:Modulus>
 *      </ds:RSAKeyValue>
 *  </ds:KeyInfo>
 *
 *  <ds:KeyInfo xmlns:ds="http://www.w3.org/2000/09/xmldsig#">
 *      <ds:KeyName> jlmkey1 </ds:KeyName>
 *      <ds:KeyType> ecc256-ecb-raw </ds:KeyType>
 *      <ds:ECCKeyValue>
 *          <ds:ECCCurve curvename="Nist256">
 *              <ds:P> Value /ds:P>
 *              <ds:A> Value /ds:A>
 *              <ds:B> Value /ds:B>
 *          </ds:ECCCurve>
 *          <ds:BasePoint>
 *              <ds:X> </ds:X>
 *              <ds:Y> </ds:Y>
 *          </ds:BasePoint>
 *          <ds:PublicBase>
 *              <ds:X> </ds:X>
 *              <ds:Y> </ds:Y>
 *          </ds:PublicBase>
 *          <ds:SecretMultiplier>AQAB</ds:SecretMultiplier>
 *          <ds:RandomMultiplier>AQAB</ds:RandomMultiplier>
 *      </ds:ECCKeyValue>
 *  </ds:KeyInfo>
 *
 *  <ds:KeyInfo xmlns:ds="http://www.w3.org/2000/09/xmldsig#">
 *      <ds:KeyName> jlmkey1 </ds:KeyName>
 *      <ds:KeyType> elgamal1024-ecb-raw </ds:KeyType>
 *      <ds:ElGamalKeyValue>
 *          <ds:Base> Value </ds:Base>
 *          <ds:SecretMultiplier>AQAB</ds:SecretMultiplier>
 *          <ds:RandomMultiplier>AQAB</ds:RandomMultiplier>
 *      </ds:ElGamal1024KeyValue>
 *  </ds:KeyInfo>
 */


int GetBase64ValueFromElement(TiXmlNode* pValueNode, byte* pValBuf, int iBufSize,
                              bool fProcessWhitespace=true)
{
    TiXmlElement*   pElement= pValueNode->ToElement();
    int             iSize= iBufSize;
    bool            fSeenWhite= false;

    if(pElement==NULL) {
        printf("No element in Value Node\n");
        return -1;
    }
    const char* pValueString= pElement->GetText();
    if(pValueString==NULL) {
        printf("No Key Value value\n");
        return -1;
    }

    if(fProcessWhitespace) {
        const char*   p= pValueString;

        while(*p!=0) {
            if(whitespace(*p++)) {
                fSeenWhite= true;
                break;
            }
        }
    }

    // get rid of whitespace
    if(fSeenWhite) {
        char*   p= strdup(pValueString);
        char*   q= p;
        char*   r= p;
                char    a;

        while(*q!=0) {
            a= *(q++);
            if(!whitespace(a)) {
                *(p++)= a;
            }
        }
        *p= 0;

        if(!fromBase64((int)strlen(r), r, &iSize, pValBuf)) {
            free(r);
            return -1;
        }

        free(r);
        return iSize;
    }

    if(!fromBase64((int)strlen(pValueString), (char*)pValueString, &iSize, pValBuf))
        return -1;
    return iSize;

}


int PutBase64Value(int iInSize, byte* pValBuf, int iBufSize, char* szOut,
                   bool fProcessWhitespace=true)
{
    int     iSize= iBufSize;

    if(!toBase64(iInSize, pValBuf, &iSize, szOut))
        return -1;

    // break up lines
    if(fProcessWhitespace && iSize>BASE64LINE) {
        int     i= (iSize-1)/BASE64LINE;
        int     j= iSize-BASE64LINE*i;
        char    a;
        char*   p;
        char*   q;

        if((i+iSize+1)>=iBufSize)
            return iSize;

        p= szOut+iSize;
        iSize+= i;
        q= szOut+iSize;

        *(q--)= 0;  *(p--)= 0;
        while(p>=szOut) {
            a= *(p--);
            *(q--)= a;
            if((--j)==0 && i>0) {
                *(q--)= '\n';
                i--;
                j= BASE64LINE;
            }
        }
    }
    return iSize;
}


bool ReadXmlStreamSymKey(keyStruct* pKey, TiXmlNode* pKeyInfoNode)
{
    TiXmlNode*      pKeyValueNode;
    symKey*         pKeyInfo= (symKey*) pKey->k_pKeyInfo;
    int             iKeyBufSize;
    int             i= 0;

    if(pKey==NULL || pKeyInfo==NULL || pKeyInfoNode==NULL)
        return false;

    pKeyValueNode= pKeyInfoNode->FirstChild("ds:KeyValue");
    if(pKeyValueNode==NULL) {
        printf("No Key Value\n");
        return false;
    }

    iKeyBufSize= getKeySize(pKey->k_uAlgorithm);
    if(iKeyBufSize<=0)
            return false;
    i= GetBase64ValueFromElement(pKeyValueNode, pKeyInfo->k_rgbKey, pKeyInfo->k_iByteSizeKey);
    if(i<0) {
        printf("No Key Value value\n");
        return false;
    }
    if(i>pKeyInfo->k_iByteSizeKey)
        return false;
    pKeyInfo->k_iByteSizeKey= i;

    return true;
}


bool ReadXmlBlockSymKey(keyStruct* pKey, TiXmlNode* pKeyInfoNode)
{
    TiXmlNode*      pKeyValueNode;
    TiXmlNode*      pIVValueNode;
    symKey*         pKeyInfo= (symKey*) pKey->k_pKeyInfo;
    int             iKeyBufSize, i;

    if(pKey==NULL || pKeyInfo==NULL || pKeyInfoNode==NULL)
        return false;

    pKeyValueNode= pKeyInfoNode->FirstChild("ds:KeyValue");
    if(pKeyValueNode==NULL) {
        printf("No Key Value\n");
        return false;
    }

    iKeyBufSize= getKeySize(pKey->k_uAlgorithm);
    if(iKeyBufSize>pKeyInfo->k_iByteSizeKey)
        return false;
    i= GetBase64ValueFromElement(pKeyValueNode, pKeyInfo->k_rgbKey, iKeyBufSize);
    if(i<0) {
        printf("No Key Value value\n");
        return false;
    }
    pKeyInfo->k_iByteSizeKey= i;

    pIVValueNode= pKeyInfoNode->FirstChild("ds:IVValue");
    if(pIVValueNode!=NULL) {

        iKeyBufSize= getKeySize(pKey->k_uAlgorithm);
        if(iKeyBufSize>pKeyInfo->k_iByteSizeIV)
            return false;
        i= GetBase64ValueFromElement(pIVValueNode, pKeyInfo->k_rgbIV, iKeyBufSize);
        if(i<0) {
            printf("No IV Value value\n");
            return false;
        }
        pKeyInfo->k_iByteSizeIV= i;
    }

    return true;
}


bool ReadXmlRSAKey(keyStruct* pKey, TiXmlNode* pKeyInfoNode)
{
    TiXmlNode*      pKeyValueNode;
    RSAKey* pKeyInfo= (RSAKey*) pKey->k_pKeyInfo;
    TiXmlNode*      pParameterNode;
    int             iBufSize, i;

    if(pKey==NULL || pKeyInfo==NULL || pKeyInfoNode==NULL)
        return false;

    pKeyValueNode= pKeyInfoNode->FirstChild("ds:RSAKeyValue");
    if(pKeyValueNode==NULL) {
        printf("No Key Value\n");
        return false;
    }

    // Get Modulus
    pParameterNode= pKeyValueNode->FirstChild("ds:Modulus");
    if(pParameterNode!=NULL) {
        iBufSize= getBlockSize(pKey->k_uAlgorithm);
        i= GetBase64ValueFromElement(pParameterNode, pKeyInfo->k_rgbM, pKeyInfo->k_iByteSizeM);
        if(i<0) {
            printf("No modulus value\n");
            return false;
        }
                if(i>iBufSize) {
                        printf("Modulus larger than allowed\n");
            return false;
        }
        pKeyInfo->k_iByteSizeM= i;
    }
    else 
        pKeyInfo->k_iByteSizeM= 0;

    // Get E 
    pParameterNode= pKeyValueNode->FirstChild("ds:E");
    if(pParameterNode!=NULL) {
        iBufSize= getBlockSize(pKey->k_uAlgorithm);
        i= GetBase64ValueFromElement(pParameterNode, pKeyInfo->k_rgbE, pKeyInfo->k_iByteSizeE);
        if(i<0) {
            printf("No E value\n");
            return false;
        }
                if(i>iBufSize) {
                        printf("E larger than allowed\n");
            return false;
        }
        pKeyInfo->k_iByteSizeE= i;
    }
    else
        pKeyInfo->k_iByteSizeE= 0;

    // Get D
    pParameterNode= pKeyValueNode->FirstChild("ds:D");
    if(pParameterNode!=NULL) {
        iBufSize= getBlockSize(pKey->k_uAlgorithm);
        i= GetBase64ValueFromElement(pParameterNode, pKeyInfo->k_rgbD, pKeyInfo->k_iByteSizeD);
        if(i<0) {
            printf("No D value\n");
            return false;
        }
                if(i>iBufSize) {
                        printf("D larger than allowed\n");
            return false;
        }
        pKeyInfo->k_iByteSizeD= i;
    }
    else
        pKeyInfo->k_iByteSizeD= 0;

    // Get P
    pParameterNode= pKeyValueNode->FirstChild("ds:P");
    if(pParameterNode!=NULL) {
        iBufSize= getBlockSize(pKey->k_uAlgorithm);
        if(iBufSize>pKeyInfo->k_iByteSizeP)
            return false;
        i= GetBase64ValueFromElement(pParameterNode, pKeyInfo->k_rgbP, pKeyInfo->k_iByteSizeP);
        if(i<0) {
            printf("No P value\n");
            return false;
        }
                if(i>iBufSize) {
                        printf("P larger than allowed\n");
            return false;
        }
        pKeyInfo->k_iByteSizeP= i;
    }
    else
        pKeyInfo->k_iByteSizeP= 0;

    // Get Q
    pParameterNode= pKeyValueNode->FirstChild("ds:Q");
    if(pParameterNode!=NULL) {
        iBufSize= getBlockSize(pKey->k_uAlgorithm);
        i= GetBase64ValueFromElement(pParameterNode, pKeyInfo->k_rgbQ, pKeyInfo->k_iByteSizeQ);
        if(i<0) {
            printf("No Q value\n");
            return false;
        }
                if(i>iBufSize) {
                        printf("Q larger than allowed\n");
            return false;
        }
        pKeyInfo->k_iByteSizeQ= i;
    }
    else
        pKeyInfo->k_iByteSizeQ= 0;

    return true;
}


bool ReadXmlECCKey(keyStruct* pKey, TiXmlNode* pKeyInfoNode)
{
    TiXmlNode*      pKeyValueNode;
    ECCKey*         pKeyInfo= (ECCKey*) pKey->k_pKeyInfo;
    TiXmlNode*      pCurveNode;
    TiXmlElement*   pCurveElement;
    TiXmlNode*      pBasePointNode;
    TiXmlNode*      pPublicBasePointNode;
    TiXmlNode*      pParameterNode;
    int             iBufSize, i;
    Curve*          pCurve= NULL;
    CurvePoint*     pG= NULL;

    if(pKey==NULL || pKeyInfo==NULL || pKeyInfoNode==NULL)
        return false;

    pKeyValueNode= pKeyInfoNode->FirstChild("ds:ECCKeyValue");
    if(pKeyValueNode==NULL) {
        printf("No Key Value\n");
        return false;
    }
    pKeyInfo->k_szCurveName= NULL;
    pKeyInfo->k_pCurve= NULL;
    pKeyInfo->k_pBasePoint= NULL;
    pKeyInfo->k_pPublicBasePoint= NULL;

    // Get Curve
    pCurveNode= pKeyValueNode->FirstChild("ds:ECCCurve");
    if(pCurveNode!=NULL) {
        pCurveElement= pCurveNode->ToElement();
        if(pCurveElement!=NULL) {
            // Curve Name
            const char* pCurveName= pCurveElement->Attribute((const char*) "curvename");
            // If Curve name is standard, don't need parameters
            if(pCurveName!=NULL) {
                if(StandardCurve(pCurveName, &pCurve, &pG)) {
                    pKeyInfo->k_pCurve= new Curve();
                    pKeyInfo->k_pCurve->Init(*pCurve);
                    pKeyInfo->k_pBasePoint= new CurvePoint();
                    pKeyInfo->k_pBasePoint->Init(*pG);
                    pKeyInfo->k_szCurveName= strdup(pCurveName);
                    pKeyInfo->k_pPublicBasePoint= new CurvePoint();
                    pKeyInfo->k_pPublicBasePoint->Init();
                }
                else {
                    // Curve parameters
                    pParameterNode= pCurveNode->FirstChild("ds:P");
                    if(pParameterNode!=NULL) {
                        iBufSize= getBlockSize(pKey->k_uAlgorithm);
                        if(iBufSize>pKeyInfo->k_iByteSizeP)
                            return false;
                        i= GetBase64ValueFromElement(pParameterNode, pKeyInfo->k_rgbP, iBufSize);
                        if(i<0) {
                            printf("No P value\n");
                            return false;
                        }
                        pKeyInfo->k_iByteSizeP= i;
                    }
                    else
                        pKeyInfo->k_iByteSizeP= 0;

                    pParameterNode= pCurveNode->FirstChild("ds:A");
                    if(pParameterNode!=NULL) {
                        iBufSize= getBlockSize(pKey->k_uAlgorithm);
                        if(iBufSize>pKeyInfo->k_iByteSizeA)
                            return false;
                        i= GetBase64ValueFromElement(pParameterNode, pKeyInfo->k_rgbA, iBufSize);
                        if(i<0) {
                            printf("No A value\n");
                            return false;
                        }
                        pKeyInfo->k_iByteSizeA= i;
                    }
                    else
                        pKeyInfo->k_iByteSizeA= 0;
         
                    pParameterNode= pCurveNode->FirstChild("ds:B");
                    if(pParameterNode!=NULL) {
                        iBufSize= getBlockSize(pKey->k_uAlgorithm);
                        if(iBufSize>pKeyInfo->k_iByteSizeB)
                            return false;
                        i= GetBase64ValueFromElement(pParameterNode, pKeyInfo->k_rgbB, iBufSize);
                        if(i<0) {
                            printf("No B value\n");
                            return false;
                        }
                        pKeyInfo->k_iByteSizeB= i;
                    }
                    else
                        pKeyInfo->k_iByteSizeB= 0;
                }
            }   // Curve name
        }       // Curve element
    }           // Curve Node

    // Multipliers (possibly)
    pParameterNode= pKeyValueNode->FirstChild("ds:SecretMultiplier");
    if(pParameterNode!=NULL) {
        iBufSize= getBlockSize(pKey->k_uAlgorithm);
        if(iBufSize>pKeyInfo->k_iByteSizeSecreta)
            return false;
        i= GetBase64ValueFromElement(pParameterNode, pKeyInfo->k_rgbSecreta, iBufSize);
        if(i<0) {
            printf("No Secret Multipler value\n");
            return false;
        }
        pKeyInfo->k_iByteSizeSecreta= i;
    }
    pParameterNode= pKeyValueNode->FirstChild("ds:RandomMultiplier");
    if(pParameterNode!=NULL) {
        iBufSize= getBlockSize(pKey->k_uAlgorithm);
        if(iBufSize>pKeyInfo->k_iByteSizeSecretb)
            return false;
        i= GetBase64ValueFromElement(pParameterNode, pKeyInfo->k_rgbSecretb, iBufSize);
        if(i<0) {
            printf("No Random Multipler value\n");
            return false;
        }
        pKeyInfo->k_iByteSizeSecretb= i;
    }
    else
        pKeyInfo->k_iByteSizeSecretb= 0;

    
    pKeyInfo->k_iByteSizeGx= 0;
    pKeyInfo->k_iByteSizeGy= 0;
    pBasePointNode= pKeyValueNode->FirstChild("ds:BasePoint");
    if(pBasePointNode!=NULL) {

        pParameterNode= pBasePointNode->FirstChild("ds:X");
        if(pParameterNode==NULL) {
            printf("No X node\n");
            return false;
        }
        iBufSize= getBlockSize(pKey->k_uAlgorithm);
        if(iBufSize>pKeyInfo->k_iByteSizeGx)
            return false;
        i= GetBase64ValueFromElement(pParameterNode, pKeyInfo->k_rgbGx, iBufSize);
        if(i<0) {
            printf("No X value\n");
            return false;
        }
        pKeyInfo->k_iByteSizeGx= i;

        pParameterNode= pBasePointNode->FirstChild("ds:Y");
        if(pParameterNode==NULL) {
            printf("No Y node\n");
            return false;
        }
        iBufSize= getBlockSize(pKey->k_uAlgorithm);
        if(iBufSize>pKeyInfo->k_iByteSizeGy)
            return false;
        i= GetBase64ValueFromElement(pParameterNode, pKeyInfo->k_rgbGy, iBufSize);
        if(i<0) {
            printf("No Y value\n");
            return false;
        }
        pKeyInfo->k_iByteSizeGy= i;
    }

    // Public BasePoint

    pPublicBasePointNode= pKeyValueNode->FirstChild("ds:PublicBase");
    if(pPublicBasePointNode!=NULL) {

        pParameterNode= pPublicBasePointNode->FirstChild("ds:X");
        if(pParameterNode==NULL) {
            printf("No X node\n");
            return false;
        }
        iBufSize= getBlockSize(pKey->k_uAlgorithm);
        if(iBufSize>pKeyInfo->k_iByteSizePubGx)
            return false;
        i= GetBase64ValueFromElement(pParameterNode, pKeyInfo->k_rgbPubGx, iBufSize);
        if(i<0) {
            printf("No X value\n");
            return false;
        }
        pKeyInfo->k_iByteSizePubGx= i;

        pParameterNode= pPublicBasePointNode->FirstChild("ds:Y");
        if(pParameterNode==NULL) {
            printf("No Y node\n");
            return false;
        }
        iBufSize= getBlockSize(pKey->k_uAlgorithm);
        if(iBufSize>pKeyInfo->k_iByteSizePubGy)
            return false;
        i= GetBase64ValueFromElement(pParameterNode, pKeyInfo->k_rgbPubGy, iBufSize);
        if(i<0) {
            printf("No Y value\n");
            return false;
        }
        pKeyInfo->k_iByteSizePubGy= i;
    }

    return true;
}


bool ReadXmlElGamalKey(keyStruct* pKey, TiXmlNode* pKeyInfoNode)
{
    TiXmlNode*      pKeyValueNode;
    ElGamalKey*     pKeyInfo= (ElGamalKey*) pKey->k_pKeyInfo;
    TiXmlNode*      pParameterNode;
    int             iBufSize, i;

    if(pKey==NULL || pKeyInfo==NULL || pKeyInfoNode==NULL)
        return false;

    pKeyValueNode= pKeyInfoNode->FirstChild("ds:ElGamalKeyValue");
    if(pKeyValueNode==NULL) {
        printf("No Key Value\n");
        return false;
    }
    // Secret Multiplier
    pParameterNode= pKeyValueNode->FirstChild("ds:SecretMultiplier");
    if(pParameterNode!=NULL) {
        iBufSize= getBlockSize(pKey->k_uAlgorithm);
        if(iBufSize>pKeyInfo->k_iByteSizeSecreta)
            return false;
        i= GetBase64ValueFromElement(pParameterNode, pKeyInfo->k_rgbSecreta, iBufSize);
        if(i<0) {
            printf("No Secret Multipler value\n");
            return false;
        }
        pKeyInfo->k_iByteSizeSecreta= i;
    }
    else
        pKeyInfo->k_iByteSizeSecreta= 0;

    // Random Multiplier
    pParameterNode= pKeyValueNode->FirstChild("ds:RandomMultiplier");
    if(pParameterNode!=NULL) {
        iBufSize= getBlockSize(pKey->k_uAlgorithm);
        if(iBufSize>pKeyInfo->k_iByteSizeSecretb)
            return false;
        i= GetBase64ValueFromElement(pParameterNode, pKeyInfo->k_rgbSecretb, iBufSize);
        if(i<0) {
            printf("No Random Multipler value\n");
            return false;
        }
        pKeyInfo->k_iByteSizeSecretb= i;
    }
    else
        pKeyInfo->k_iByteSizeSecretb= 0;

    // P
    pParameterNode= pKeyValueNode->FirstChild("ds:P");
    if(pParameterNode!=NULL) {
        iBufSize= getBlockSize(pKey->k_uAlgorithm);
        if(iBufSize>pKeyInfo->k_iByteSizeP)
            return false;
        i= GetBase64ValueFromElement(pParameterNode, pKeyInfo->k_rgbP, iBufSize);
        if(i<0) {
            printf("No P value\n");
            return false;
        }
        pKeyInfo->k_iByteSizeP= i;
    }
    else
        pKeyInfo->k_iByteSizeP= 0;

    // G
    pParameterNode= pKeyValueNode->FirstChild("ds:G");
    if(pParameterNode!=NULL) {
        iBufSize= getBlockSize(pKey->k_uAlgorithm);
        if(iBufSize>pKeyInfo->k_iByteSizeG)
            return false;
        i= GetBase64ValueFromElement(pParameterNode, pKeyInfo->k_rgbG, iBufSize);
        if(i<0) {
            printf("No G value\n");
            return false;
        }
        pKeyInfo->k_iByteSizeG= i;
        }
    else
        pKeyInfo->k_iByteSizeG= 0;

    return true;
}


bool ReadXmlKey(char* szXmlInput, keyStruct* pKey)
{
    int             iKeyNameSize;
    TiXmlDocument*  pDoc= new TiXmlDocument(); 
    TiXmlNode*      pKeyNameNode;
    TiXmlNode*      pKeyTypeNode;
    TiXmlElement*   pElement;
    KeyInfo*        pKeyInfo= NULL;
    byte            uT;
    byte            uAlg;

    pDoc->Parse((const char*)szXmlInput);
    if(pDoc->Error()) {
        printf("Error parsing KeyInfo Document\n");
        return false;
    }

    TiXmlNode* pKeyInfoNode= pDoc->FirstChild("ds:KeyInfo");
    if(pKeyInfoNode==NULL) {
        printf("No KeyInfo Element\n");
        return false;
    }

    pKeyNameNode= pKeyInfoNode->FirstChild("ds:KeyName");
    pElement= pKeyNameNode->ToElement();
    const char* pKeyName= pElement->GetText();
    if(pKeyName==NULL) {
        pKey->k_ikeyNameSize= 0;
    }
    else {
        iKeyNameSize= (int)strlen(pKeyName)+1;
        if(iKeyNameSize > KEYNAMEBUFSIZE) {
           printf("Key Name too long for buffer\n");
           return false;
        }
        memcpy((void*) pKey->k_rgkeyName, (void*) pKeyName, (size_t) iKeyNameSize);
        pKey->k_ikeyNameSize= iKeyNameSize;
    }

    pKeyTypeNode= pKeyInfoNode->FirstChild("ds:KeyType");
    pElement= pKeyTypeNode->ToElement();
    const char* pKeyType= pElement->GetText();
    if(pKeyType==NULL) {
        pKey->k_ikeyTypeSize= 0;
    }
    else {
        int iKeyTypeSize= (int)strlen(pKeyType)+1;
        if(iKeyTypeSize > KEYTYPEBUFSIZE) {
            printf("Key Type too long for buffer\n");
            return false;
        }
        memcpy((void*) pKey->k_rgkeyType, (void*) pKeyType, (size_t) iKeyTypeSize);
        pKey->k_ikeyTypeSize= iKeyTypeSize;
        }

    // Have key type set key
    if((pKey->k_uAlgorithm=ValidAlgorithmName((char*)pKeyType))==0) {
         printf("Unknown Key Type\n");
        return false;
    }
    uAlg= getBasicAlgPart(pKey->k_uAlgorithm);
    uT= getTypePart(pKey->k_uAlgorithm);
    if(uT==BLOCK || uT==STREAM) {
        pKey->k_pKeyInfo= (KeyInfo*) new symKey();
        if(pKey->k_pKeyInfo==NULL)
                return false;
    }
    else {
        switch(uAlg) {
          case RSA1024:
          case RSA2048:
            pKey->k_pKeyInfo= (KeyInfo*) new RSAKey();
            if(pKey->k_pKeyInfo==NULL)
                return false;
            break;
          case ECC256:
          case ECC521:
            pKey->k_pKeyInfo= (KeyInfo*) new ECCKey();
            if(pKey->k_pKeyInfo==NULL)
                return false;
            break;
          case ELGAMAL1024:
          case ELGAMAL2048:
            pKey->k_pKeyInfo= (KeyInfo*) new ECCKey();
            if(pKey->k_pKeyInfo==NULL)
                return false;
            break;
          default:
            return false;
          }
    }

    if(uT==BLOCK) {
        return ReadXmlBlockSymKey(pKey, pKeyInfoNode);
    }
    else if(uT==STREAM) {
        return ReadXmlStreamSymKey(pKey, pKeyInfoNode);
    }
    else if(uAlg==RSA1024 || uAlg==RSA2048) {
        return ReadXmlRSAKey(pKey, pKeyInfoNode);
    }
    else if(uAlg==ELGAMAL1024 || uAlg==ELGAMAL2048) {
        return ReadXmlElGamalKey(pKey, pKeyInfoNode);
    }
    else if(uAlg==ECC256 || uAlg==ECC521) {
        return ReadXmlECCKey(pKey, pKeyInfoNode);
    }
    else
            return false;
}


static char*   s_szKeyInfob= "\n<ds:KeyInfo xmlns:ds=\"http://manferdelli.org/keyformats\">\n";
static char*   s_szKeyInfoe= "\n</ds:KeyInfo>\n";

static char*   s_szKeyNameb= "\t<ds:KeyName> ";
static char*   s_szKeyNamee= "</ds:KeyName>\n";

static char*   s_szKeyTypeb= "\t<ds:KeyType> ";
static char*   s_szKeyTypee= " </ds:KeyType>\n";

static char*   s_szKeyValb= "\t<ds:KeyValue>\n";
static char*   s_szKeyVale= "\n\t</ds:KeyValue>\n";

static char*   s_szIVValb= "\t<ds:IVValue>\n";
static char*   s_szIVVale= "\n\t</ds:IVValue>\n";

static char*   s_szParamNamebb= "\t<ds:Parameter name=\"";
static char*   s_szParamNamebe= "\">\n";
static char*   s_szParamNamee= " </ds:Parameter>\n";

static char*   s_szECCKeyValb= "\t<ds:ECCKeyValue>\n";
static char*   s_szECCKeyVale= "\n\t</ds:ECCKeyValue>\n";

static char*   s_szECCCurbb= "\t\t<ds:ECCCurve curvename=\"";
static char*   s_szECCCurbe= "\">\n";
static char*   s_szECCCure= "\n\t\t</ds:ECCCurve>\n";

static char*   s_szRSAKeyValb= "\t<ds:RSAKeyValue>\n";
static char*   s_szRSAKeyVale= "\n\t</ds:RSAKeyValue>\n";
static char*   s_szModulusb= "\t<ds:Modulus>\n";
static char*   s_szModuluse= "\n\t</ds:Modulus>\n";
static char*   s_szEb= "\t<ds:E>\n";
static char*   s_szEe= "\n\t</ds:E>\n";
static char*   s_szDb= "\t<ds:D>\n";
static char*   s_szDe= "\n\t</ds:D>\n";
static char*   s_szPb= "\t<ds:P>\n";
static char*   s_szPe= "\n\t</ds:P>\n";
static char*   s_szQb= "\t<ds:Q>\n";
static char*   s_szQe= "\n\t</ds:Q>\n";

static char*   s_szElGamalKeyValb= "\t<ds:ElGamalKeyValue>\n";
static char*   s_szElGamalKeyVale= "\n\t</ds:ElGamalKeyValue>\n";
static char*   s_szBaseb= "\t<ds:Base>\n";
static char*   s_szBasee= "\n\t</ds:Base>\n";

static char*   s_szAb= "\t\t<ds:A>\n";
static char*   s_szAe= "\n\t\t</ds:A>\n";
static char*   s_szBb= "\t\t<ds:B>\n";
static char*   s_szBe= "\n\t\t</ds:B>\n";
static char*   s_szBasePointb= "\t\t<ds:BasePoint>\n";
static char*   s_szBasePointe= "\n\t\t</ds:BasePoint>\n";
static char*   s_szXb= "\t\t<ds:X> \n";
static char*   s_szXe= "\n\t\t</ds:X>\n";
static char*   s_szYb= "\t\t<ds:Y> \n";
static char*   s_szYe= "\n\t\t</ds:Y>\n";
static char*   s_szPublicBaseb= "\t\t<ds:PublicBase>\n";
static char*   s_szPublicBasee= "\n\t\t</ds:PublicBase>\n";
static char*   s_szSecretMultiplierb= "\t\t<ds:SecretMultiplier>\n";
static char*   s_szSecretMultipliere= "\n\t\t</ds:SecretMultiplier>\n";
static char*   s_szRandomMultiplierb= "\t\t<ds:RandomMultiplier>\n";
static char*   s_szRandomMultipliere= "\n\t\t</ds:RandomMultiplier>\n";


inline int PasteString(char* szString, char* pBuf, int iBufLen)
{
    int iThisSize= (int)strlen(szString);
    if(iThisSize>=iBufLen)
        return -1;
    memcpy((void*)pBuf, (void*)szString, iThisSize);
    return iThisSize;
}


int WriteXmlSymmetricKey(keyStruct* pKey, int iBufSize, char* szBuf)
{
    int     iCurPos= 0;
    int     iLen;
    int     iSize;
    symKey* pKeyInfo= (symKey*) pKey->k_pKeyInfo;

    // Key Value
    if(pKeyInfo->k_iByteSizeKey>0) {
        if((iLen=PasteString(s_szKeyValb, &szBuf[iCurPos], iBufSize-iCurPos))<0)
            return -1;
        iCurPos+= iLen;
        iSize= iBufSize-iCurPos;
        iLen= PutBase64Value(pKeyInfo->k_iByteSizeKey, pKeyInfo->k_rgbKey, iSize, &szBuf[iCurPos]);
        if(iLen<1)
            return -1;
        iCurPos+= iLen;
        if((iLen=PasteString(s_szKeyVale, &szBuf[iCurPos], iBufSize-iCurPos))<0)
            return -1;
        iCurPos+= iLen;
    }
    if(pKeyInfo->k_iByteSizeIV>0) {
        if((iLen=PasteString(s_szIVValb, &szBuf[iCurPos], iBufSize-iCurPos))<0)
            return -1;
        iCurPos+= iLen;
        iSize= iBufSize-iCurPos;
        iLen= PutBase64Value(pKeyInfo->k_iByteSizeIV, pKeyInfo->k_rgbIV, iSize, &szBuf[iCurPos]);
        if(iLen<1)
            return -1;
        iCurPos+= iLen;
        if((iLen=PasteString(s_szIVVale, &szBuf[iCurPos], iBufSize-iCurPos))<0)
            return -1;
        iCurPos+= iLen;
    }
    return(iCurPos);
}


int WriteXmlRSAKey(keyStruct* pKey, int iBufSize, char* szBuf)
{
    int     iCurPos= 0;
    int     iLen;
    int     iSize;
    RSAKey* pKeyInfo= (RSAKey*) pKey->k_pKeyInfo;

    if((iLen=PasteString(s_szRSAKeyValb, &szBuf[iCurPos], iBufSize-iCurPos))<0)
        return -1;
    iCurPos+= iLen;

    // Modulus
    if(pKeyInfo->k_iByteSizeM>0) {
        if((iLen=PasteString(s_szModulusb, &szBuf[iCurPos], iBufSize-iCurPos))<0)
            return -1;
        iCurPos+= iLen;
        iSize= iBufSize-iCurPos;
        iLen= PutBase64Value(pKeyInfo->k_iByteSizeM, pKeyInfo->k_rgbM, iSize, &szBuf[iCurPos]);
        if(iLen<1)
            return -1;
        iCurPos+= iLen;
        if((iLen=PasteString(s_szModuluse, &szBuf[iCurPos], iBufSize-iCurPos))<0)
            return -1;
        iCurPos+= iLen;
    }

    // Public Exponent
    if(pKeyInfo->k_iByteSizeE>0) {
        if((iLen=PasteString(s_szEb, &szBuf[iCurPos], iBufSize-iCurPos))<0)
            return -1;
        iCurPos+= iLen;
        iSize= iBufSize-iCurPos;
        iLen= PutBase64Value(pKeyInfo->k_iByteSizeE, pKeyInfo->k_rgbE, iSize, &szBuf[iCurPos]);
        if(iLen<1)
            return -1;
        iCurPos+= iLen;
        if((iLen=PasteString(s_szEe, &szBuf[iCurPos], iBufSize-iCurPos))<0)
            return -1;
        iCurPos+= iLen;
    }

    // P
    if(pKeyInfo->k_iByteSizeP>0) {
        if((iLen=PasteString(s_szPb, &szBuf[iCurPos], iBufSize-iCurPos))<0)
            return -1;
        iCurPos+= iLen;
        iSize= iBufSize-iCurPos;
        iLen= PutBase64Value(pKeyInfo->k_iByteSizeP, pKeyInfo->k_rgbP, iSize, &szBuf[iCurPos]);
        if(iLen<1)
            return -1;
        iCurPos+= iLen;
        if((iLen=PasteString(s_szPe, &szBuf[iCurPos], iBufSize-iCurPos))<0)
            return -1;
        iCurPos+= iLen;
    }

    // Q
    if(pKeyInfo->k_iByteSizeQ>0) {
        if((iLen=PasteString(s_szQb, &szBuf[iCurPos], iBufSize-iCurPos))<0)
            return -1;
        iCurPos+= iLen;
        iSize= iBufSize-iCurPos;
        iLen= PutBase64Value(pKeyInfo->k_iByteSizeQ, pKeyInfo->k_rgbQ, iSize, &szBuf[iCurPos]);
        if(iLen<1)
            return -1;
        iCurPos+= iLen;
        if((iLen=PasteString(s_szQe, &szBuf[iCurPos], iBufSize-iCurPos))<0)
            return -1;
        iCurPos+= iLen;
    }

    // D
    if(pKeyInfo->k_iByteSizeD>0) {
        if((iLen=PasteString(s_szDb, &szBuf[iCurPos], iBufSize-iCurPos))<0)
            return -1;
        iCurPos+= iLen;
        iSize= iBufSize-iCurPos;
        iLen= PutBase64Value(pKeyInfo->k_iByteSizeD, pKeyInfo->k_rgbD, iSize, &szBuf[iCurPos]);
        if(iLen<1)
            return -1;
        iCurPos+= iLen;
        if((iLen=PasteString(s_szDe, &szBuf[iCurPos], iBufSize-iCurPos))<0)
            return -1;
        iCurPos+= iLen;
    }
    
    if((iLen=PasteString(s_szRSAKeyVale, &szBuf[iCurPos], iBufSize-iCurPos))<0)
        return -1;
    iCurPos+= iLen;
    return(iCurPos);
}


int WriteXmlECCKey(keyStruct* pKey, int iBufSize, char* szBuf)
{
    int     iCurPos= 0;
    int     iLen;
    int     iSize;
    ECCKey* pKeyInfo= (ECCKey*) pKey->k_pKeyInfo;

    if((iLen=PasteString(s_szECCKeyValb, &szBuf[iCurPos], iBufSize-iCurPos))<0)
        return -1;
    iCurPos+= iLen;

    // Curve
    if(pKeyInfo->k_szCurveName!=NULL) {
        if((iLen=PasteString(s_szECCCurbb, &szBuf[iCurPos], iBufSize-iCurPos))<0)
            return -1;
        iCurPos+= iLen;
        if((iLen=PasteString(pKeyInfo->k_szCurveName, &szBuf[iCurPos], iBufSize-iCurPos))<0)
            return -1;
        iCurPos+= iLen;
    
        // CurveName
        if((iLen=PasteString(s_szECCCurbe, &szBuf[iCurPos], iBufSize-iCurPos))<0)
            return -1;
        iCurPos+= iLen;
    }

    // y^2= x^3+Bx+A (mod P)
    //
    //  P
    if(pKeyInfo->k_iByteSizeP>0) {
        if((iLen=PasteString(s_szPb, &szBuf[iCurPos], iBufSize-iCurPos))<0)
            return -1;
        iCurPos+= iLen;
        iSize= iBufSize-iCurPos;
        iLen= PutBase64Value(pKeyInfo->k_iByteSizeP, pKeyInfo->k_rgbP, iSize, &szBuf[iCurPos]);
        if(iLen<1)
            return -1;
        iCurPos+= iLen;
        if((iLen=PasteString(s_szPe, &szBuf[iCurPos], iBufSize-iCurPos))<0)
            return -1;
        iCurPos+= iLen;
    }

    //  A
    if(pKeyInfo->k_iByteSizeA>0) {
        if((iLen=PasteString(s_szAb, &szBuf[iCurPos], iBufSize-iCurPos))<0)
            return -1;
        iCurPos+= iLen;
        iSize= iBufSize-iCurPos;
        iLen= PutBase64Value(pKeyInfo->k_iByteSizeA, pKeyInfo->k_rgbA, iSize, &szBuf[iCurPos]);
        if(iLen<1)
            return -1;
        iCurPos+= iLen;
        if((iLen=PasteString(s_szAe, &szBuf[iCurPos], iBufSize-iCurPos))<0)
            return -1;
        iCurPos+= iLen;
    }

    //  B
    if(pKeyInfo->k_iByteSizeB>0) {
        if((iLen=PasteString(s_szBb, &szBuf[iCurPos], iBufSize-iCurPos))<0)
            return -1;
        iCurPos+= iLen;
        iSize= iBufSize-iCurPos;
        iLen= PutBase64Value(pKeyInfo->k_iByteSizeB, pKeyInfo->k_rgbB, iSize, &szBuf[iCurPos]);
        if(iLen<1)
            return -1;
        iCurPos+= iLen;
        if((iLen=PasteString(s_szBe, &szBuf[iCurPos], iBufSize-iCurPos))<0)
            return -1;
        iCurPos+= iLen;
    }

    // End Curve
    if(pKeyInfo->k_szCurveName!=NULL) {
        if((iLen=PasteString(s_szECCCure, &szBuf[iCurPos], iBufSize-iCurPos))<0)
            return -1;
        iCurPos+= iLen;
    }

    // Base Point
    if(pKeyInfo->k_iByteSizeGx>0 && pKeyInfo->k_iByteSizeGx>0) {
        if((iLen=PasteString(s_szBasePointb, &szBuf[iCurPos], iBufSize-iCurPos))<0)
            return -1;
        iCurPos+= iLen;
        if((iLen=PasteString(s_szXb, &szBuf[iCurPos], iBufSize-iCurPos))<0)
            return -1;
        iCurPos+= iLen;
        iSize= iBufSize-iCurPos;
        iLen= PutBase64Value(pKeyInfo->k_iByteSizeGx, pKeyInfo->k_rgbGx, iSize, &szBuf[iCurPos]);
        if(iLen<1)
            return -1;
        iCurPos+= iLen;
        if((iLen=PasteString(s_szXe, &szBuf[iCurPos], iBufSize-iCurPos))<0)
            return -1;
        iCurPos+= iLen;
        if((iLen=PasteString(s_szYb, &szBuf[iCurPos], iBufSize-iCurPos))<0)
            return -1;
        iCurPos+= iLen;
        iSize= iBufSize-iCurPos;
        iLen= PutBase64Value(pKeyInfo->k_iByteSizeGy, pKeyInfo->k_rgbGy, iSize, &szBuf[iCurPos]);
        if(iLen<1)
            return -1;
        iCurPos+= iLen;
        if((iLen=PasteString(s_szYe, &szBuf[iCurPos], iBufSize-iCurPos))<0)
            return -1;
        iCurPos+= iLen;
        if((iLen=PasteString(s_szBasePointe, &szBuf[iCurPos], iBufSize-iCurPos))<0)
            return -1;
        iCurPos+= iLen;
    }

    // Public Base Point
    if(pKeyInfo->k_iByteSizePubGx>0 && pKeyInfo->k_iByteSizePubGx>0) {
        if((iLen=PasteString(s_szPublicBaseb, &szBuf[iCurPos], iBufSize-iCurPos))<0)
            return -1;
        iCurPos+= iLen;
        if((iLen=PasteString(s_szXb, &szBuf[iCurPos], iBufSize-iCurPos))<0)
            return -1;
        iCurPos+= iLen;
        iSize= iBufSize-iCurPos;
        iLen= PutBase64Value(pKeyInfo->k_iByteSizePubGx, pKeyInfo->k_rgbPubGx, 
                             iSize, &szBuf[iCurPos]);
        if(iLen<1)
            return -1;
        iCurPos+= iLen;
        if((iLen=PasteString(s_szXe, &szBuf[iCurPos], iBufSize-iCurPos))<0)
            return -1;
        iCurPos+= iLen;
        if((iLen=PasteString(s_szYb, &szBuf[iCurPos], iBufSize-iCurPos))<0)
            return -1;
        iCurPos+= iLen;
        iSize= iBufSize-iCurPos;
        iLen= PutBase64Value(pKeyInfo->k_iByteSizePubGy, pKeyInfo->k_rgbPubGy, 
                             iSize, &szBuf[iCurPos]);
        if(iLen<1)
            return -1;
        iCurPos+= iLen;
        if((iLen=PasteString(s_szYe, &szBuf[iCurPos], iBufSize-iCurPos))<0)
            return -1;
        iCurPos+= iLen;
        if((iLen=PasteString(s_szPublicBasee, &szBuf[iCurPos], iBufSize-iCurPos))<0)
            return -1;
        iCurPos+= iLen;
    }

    // Secret A
    if(pKeyInfo->k_iByteSizeSecreta>0) {
        if((iLen=PasteString(s_szSecretMultiplierb, &szBuf[iCurPos], iBufSize-iCurPos))<0)
            return -1;
        iCurPos+= iLen;
        iSize= iBufSize-iCurPos;
        iLen= PutBase64Value(pKeyInfo->k_iByteSizeSecreta, pKeyInfo->k_rgbSecreta, 
                             iSize, &szBuf[iCurPos]);
        if(iLen<1)
            return -1;
        iCurPos+= iLen;
        if((iLen=PasteString(s_szSecretMultipliere, &szBuf[iCurPos], iBufSize-iCurPos))<0)
            return -1;
        iCurPos+= iLen;
    }

    // Secret B
    if(pKeyInfo->k_iByteSizeSecretb>0) {
        if((iLen=PasteString(s_szRandomMultiplierb, &szBuf[iCurPos], iBufSize-iCurPos))<0)
            return -1;
        iCurPos+= iLen;
        iSize= iBufSize-iCurPos;
        iLen= PutBase64Value(pKeyInfo->k_iByteSizeSecretb, pKeyInfo->k_rgbSecretb, 
                             iSize, &szBuf[iCurPos]);
        if(iLen<1)
            return -1;
        iCurPos+= iLen;
        if((iLen=PasteString(s_szRandomMultipliere, &szBuf[iCurPos], iBufSize-iCurPos))<0)
            return -1;
        iCurPos+= iLen;
    }
    
    if((iLen=PasteString(s_szECCKeyVale, &szBuf[iCurPos], iBufSize-iCurPos))<0)
        return -1;
    iCurPos+= iLen;

    return(iCurPos);
}


int WriteXmlElGamalKey(keyStruct* pKey, int iBufSize, char* szBuf)
{
    int         iCurPos= 0;
    int         iLen;
    int         iSize;
    ElGamalKey* pKeyInfo= (ElGamalKey*) pKey->k_pKeyInfo;

    if((iLen=PasteString(s_szElGamalKeyValb, &szBuf[iCurPos], iBufSize-iCurPos))<0)
        return -1;
    iCurPos+= iLen;

    // Prime
    if(pKeyInfo->k_iByteSizeP>0) {
        if((iLen=PasteString(s_szPb, &szBuf[iCurPos], iBufSize-iCurPos))<0)
            return -1;
        iCurPos+= iLen;
        iSize= iBufSize-iCurPos;
        iLen= PutBase64Value(pKeyInfo->k_iByteSizeP, pKeyInfo->k_rgbP, iSize, &szBuf[iCurPos]);
        if(iLen<1)
            return -1;
        iCurPos+= iLen;
        if((iLen=PasteString(s_szPe, &szBuf[iCurPos], iBufSize-iCurPos))<0)
            return -1;
        iCurPos+= iLen;
    }

    // Base
    if(pKeyInfo->k_iByteSizeG>0) {
        if((iLen=PasteString(s_szBaseb, &szBuf[iCurPos], iBufSize-iCurPos))<0)
            return -1;
        iCurPos+= iLen;
        iSize= iBufSize-iCurPos;
        iLen= PutBase64Value(pKeyInfo->k_iByteSizeG, pKeyInfo->k_rgbG, iSize, &szBuf[iCurPos]);
        if(iLen<1)
            return -1;
        iCurPos+= iLen;
        if((iLen=PasteString(s_szBasee, &szBuf[iCurPos], iBufSize-iCurPos))<0)
            return -1;
        iCurPos+= iLen;
    }

    // Public Multiplier
    if(pKeyInfo->k_iByteSizePublicMultiplier>0) {
        if((iLen=PasteString(s_szPublicBaseb, &szBuf[iCurPos], iBufSize-iCurPos))<0)
            return -1;
        iCurPos+= iLen;
        iSize= iBufSize-iCurPos;
        iLen= PutBase64Value(pKeyInfo->k_iByteSizePublicMultiplier, 
                             pKeyInfo->k_rgbPublicMultiplier, 
                             iSize, &szBuf[iCurPos]);
        if(iLen<1)
            return -1;
        iCurPos+= iLen;
        if((iLen=PasteString(s_szPublicBasee, &szBuf[iCurPos], iBufSize-iCurPos))<0)
            return -1;
        iCurPos+= iLen;
    }

    // Secret Multiplier
    if(pKeyInfo->k_iByteSizeSecreta>0) {
        if((iLen=PasteString(s_szSecretMultiplierb, &szBuf[iCurPos], iBufSize-iCurPos))<0)
            return -1;
        iCurPos+= iLen;
        iSize= iBufSize-iCurPos;
        iLen= PutBase64Value(pKeyInfo->k_iByteSizeSecreta, pKeyInfo->k_rgbSecreta, 
                             iSize, &szBuf[iCurPos]);
        if(iLen<1)
            return -1;
        iCurPos+= iLen;
        if((iLen=PasteString(s_szSecretMultipliere, &szBuf[iCurPos], iBufSize-iCurPos))<0)
            return -1;
        iCurPos+= iLen;
    }

    // Random Multiplier
    if(pKeyInfo->k_iByteSizeSecretb>0) {
        if((iLen=PasteString(s_szRandomMultiplierb, &szBuf[iCurPos], iBufSize-iCurPos))<0)
            return -1;
        iCurPos+= iLen;
        iSize= iBufSize-iCurPos;
        iLen= PutBase64Value(pKeyInfo->k_iByteSizeSecretb, pKeyInfo->k_rgbSecretb, 
                             iSize, &szBuf[iCurPos]);
        if(iLen<1)
            return -1;
        iCurPos+= iLen;
        if((iLen=PasteString(s_szRandomMultipliere, &szBuf[iCurPos], iBufSize-iCurPos))<0)
            return -1;
        iCurPos+= iLen;
    }

    if((iLen=PasteString(s_szElGamalKeyVale, &szBuf[iCurPos], iBufSize-iCurPos))<0)
        return -1;
    iCurPos+= iLen;

    return(iCurPos);
}


int WriteXmlKey(keyStruct* pKey, int iBufSize, char* szBuf)
{
    int     iCurPos= 0;
    int     iLen;
    byte    bAlgType;
    int     i;

    if((iLen=PasteString(s_szKeyInfob, &szBuf[iCurPos], iBufSize-iCurPos))<0)
        return -1;
    iCurPos+= iLen;

    // Key Type is mandatory
    if(pKey->k_ikeyTypeSize<=0) {
        printf("Key Type is mandatory\n");
        return -1;
    }
    if((iLen=PasteString(s_szKeyTypeb, &szBuf[iCurPos], iBufSize-iCurPos))<0)
        return -1;
    iCurPos+= iLen;

    if((iLen=PasteString(pKey->k_rgkeyType, &szBuf[iCurPos], iBufSize-iCurPos))<0)
        return -1;
    iCurPos+= iLen;

    if((iLen=PasteString(s_szKeyTypee, &szBuf[iCurPos], iBufSize-iCurPos))<0)
        return -1;
    iCurPos+= iLen;

    if(pKey->k_ikeyNameSize>0) {
        if((iLen=PasteString(s_szKeyNameb, &szBuf[iCurPos], iBufSize-iCurPos))<0)
            return -1;
        iCurPos+= iLen;

        if((iLen=PasteString(pKey->k_rgkeyName, &szBuf[iCurPos], iBufSize-iCurPos))<0)
            return -1;
        iCurPos+= iLen;

        if((iLen=PasteString(s_szKeyNamee, &szBuf[iCurPos], iBufSize-iCurPos))<0)
            return -1;
        iCurPos+= iLen;
    }

    bAlgType= getTypePart(pKey->k_uAlgorithm);
    if(bAlgType==BLOCK || bAlgType==STREAM) {
        // symmetric key
        i= WriteXmlSymmetricKey(pKey, iBufSize-iCurPos, &szBuf[iCurPos]);
        if(i<0)
            return -1;
        iCurPos+= i;
    }
    else {
        switch(getBasicAlgPart(pKey->k_uAlgorithm)) {
          case RSA1024:
          case RSA2048:
            i= WriteXmlRSAKey(pKey, iBufSize-iCurPos, &szBuf[iCurPos]);
            if(i<0)
                return -1;
            iCurPos+= i;
            break;
          case ECC256:
          case ECC521:
            i= WriteXmlECCKey(pKey, iBufSize-iCurPos, &szBuf[iCurPos]);
            if(i<0)
                return -1;
            iCurPos+= i;
            break;
          case ELGAMAL1024:
          case ELGAMAL2048:
            i= WriteXmlElGamalKey(pKey, iBufSize-iCurPos, &szBuf[iCurPos]);
            if(i<0)
                return -1;
            iCurPos+= i;
            break;
          default:
            return -1;
          }
    }

    if((iLen=PasteString(s_szKeyInfoe, &szBuf[iCurPos], iBufSize-iCurPos))<0)
        return -1;
    iCurPos+= iLen;
    szBuf[iCurPos++]= '\0';

    return(iCurPos);
}



// ---------------------------------------------------------------------------------------


