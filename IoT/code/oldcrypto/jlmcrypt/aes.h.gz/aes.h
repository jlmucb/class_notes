//
//  Module Name: aes.h
//
//  This module contains the low-level AES encryption routines.
//  Derived from public domain sources and modified for usage in the NT
//  programming environment.
//
//      Modified by John Manferdelli from a public domain version by:
//              Vincent Rijmen <vincent.rijmen@esat.kuleuven.ac.be>
//              Antoon Bosselaers <antoon.bosselaers@esat.kuleuven.ac.be>
//              Paulo Barreto <paulo.barreto@terra.com.br>


// ------------------------------------------------------------------------


#ifndef __AES_H
#define __AES_H

#include "windows.h"

typedef unsigned unsigned32;
typedef unsigned char unsigned8;

#define MAXKC   (256/32)
#define MAXKB   (256/8)
#define MAXNR   14

typedef unsigned char   unsigned8;      
typedef unsigned short  unsigned16;     
typedef unsigned        unsigned32;


class aes {
private:
        int             m_Nr;
        unsigned32      m_rk[4*(MAXNR+1)];

public:
        aes() {m_Nr= 0;};
        ~aes() {memset(m_rk, 0,4*(MAXNR+1));};

        int     KeySetupEnc(const unsigned8 cipherKey[], int keyBits);
        int     KeySetupDec(const unsigned8 cipherKey[], int keyBits);
        void    Encrypt(const unsigned8 pt[16], unsigned8 ct[16]);
        void    Decrypt(const unsigned8 ct[16], unsigned8 pt[16]);
        void    CleanKeys();
        };

#endif


// ------------------------------------------------------------------------

