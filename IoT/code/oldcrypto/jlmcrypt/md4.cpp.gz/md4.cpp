#include "md4.h"
#include "string.h"
#ifdef MSC
#include "disable.h"
#endif


// ----------------------------------------------------------------------


#define PUT_64BIT_LE(cp, value) do {                                    \
        (cp)[7] = (value) >> 56;                                        \
        (cp)[6] = (value) >> 48;                                        \
        (cp)[5] = (value) >> 40;                                        \
        (cp)[4] = (value) >> 32;                                        \
        (cp)[3] = (value) >> 24;                                        \
        (cp)[2] = (value) >> 16;                                        \
        (cp)[1] = (value) >> 8;                                         \
        (cp)[0] = (value); } while (0)
                        
#define PUT_32BIT_LE(cp, value) do {                                    \
        (cp)[3] = (value) >> 24;                                        \
        (cp)[2] = (value) >> 16;                                        \
        (cp)[1] = (value) >> 8;                                         \
        (cp)[0] = (value); } while (0)
                                        
static u8 PADDING[MD4_BLOCK_LENGTH] = {
        0x80, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};


// ----------------------------------------------------------------------


void MD4::Init()
{
    count = 0;
    state[0] = 0x67452301;
    state[1] = 0xefcdab89;
    state[2] = 0x98badcfe;
    state[3] = 0x10325476;
}
          

void MD4::Update(u8* input, u64 len)
{
    u64 have, need;
            
    /* Check how many bytes we already have and how many more we need. */
    have = (u64)((count >> 3) & (MD4_BLOCK_LENGTH - 1));
    need = MD4_BLOCK_LENGTH - have;
            
    /* Update bitcount */
    count += (u64)len << 3;
            
    if (len >= need) {
        if (have != 0) {
            memcpy(buffer + have, input, need);
            Transform(state, buffer);
            input += need;
            len -= need;
            have = 0;
        }
                                
        /* Process data in MD4_BLOCK_LENGTH-byte chunks. */
        while (len >= MD4_BLOCK_LENGTH) {
            Transform(state, input);
            input += MD4_BLOCK_LENGTH;
            len -= MD4_BLOCK_LENGTH;
        }
    }
                                                        
    /* Handle any remaining bytes of data. */
    if (len != 0)
        memcpy(buffer + have, input, len);
}
                                                        


void MD4::Pad()
{
    u8 padcount[8];
    u64 padlen;
                
    /* Convert count to 8 bytes in little endian order. */
    PUT_64BIT_LE(padcount, count);
                
    /* Pad out to 56 mod 64. */
    padlen= MD4_BLOCK_LENGTH - ((count >> 3) & (MD4_BLOCK_LENGTH - 1));
    if (padlen < 1 + 8)
        padlen += MD4_BLOCK_LENGTH;
    Update(PADDING, padlen - 8);            /* padlen - 8 <= 64 */
    Update(padcount, 8);
}

                
void MD4::Final(u8 digest[MD4_DIGEST_LENGTH])
{
    int i;
        
    Pad();
    if(digest != NULL) {
        for (i = 0; i < 4; i++)
            PUT_32BIT_LE(digest + i * 4, state[i]);
    }
}
                        

/* #define F1(x, y, z) (x & y | ~x & z) */
#define F1(x, y, z) (z ^ (x & (y ^ z)))
#define F2(x, y, z) ((x & y) | (x & z) | (y & z))
#define F3(x, y, z) (x ^ y ^ z)
        
/* This is the central step in the MD4 algorithm. */
#define MD4STEP(f, w, x, y, z, data, s) \
            ( w += f(x, y, z) + data,  w = w<<s | w>>(32-s) )
         

void MD4::Transform(u32 state[4], const u8 block[MD4_BLOCK_LENGTH])
{
    u32 a, b, c, d, in[MD4_BLOCK_LENGTH / 4];
        
#if BYTE_ORDER == LITTLE_ENDIAN
    memcpy(in, block, sizeof(in));
#else
    for (a = 0; a < MD4_BLOCK_LENGTH / 4; a++) {
        in[a] = (u32)( (u32)(block[a * 4 + 0]) | (u32)(block[a * 4 + 1]) <<  8 |
                       (u32)(block[a * 4 + 2]) << 16 | (u32)(block[a * 4 + 3]) << 24);
    }
#endif
                                        
    a = state[0];
    b = state[1];
    c = state[2];
    d = state[3];
                                
    MD4STEP(F1, a, b, c, d, in[ 0],  3);
    MD4STEP(F1, d, a, b, c, in[ 1],  7);
    MD4STEP(F1, c, d, a, b, in[ 2], 11);
    MD4STEP(F1, b, c, d, a, in[ 3], 19);
    MD4STEP(F1, a, b, c, d, in[ 4],  3);
    MD4STEP(F1, d, a, b, c, in[ 5],  7);
    MD4STEP(F1, c, d, a, b, in[ 6], 11);
    MD4STEP(F1, b, c, d, a, in[ 7], 19);
    MD4STEP(F1, a, b, c, d, in[ 8],  3);
    MD4STEP(F1, d, a, b, c, in[ 9],  7);
    MD4STEP(F1, c, d, a, b, in[10], 11);
    MD4STEP(F1, b, c, d, a, in[11], 19);
    MD4STEP(F1, a, b, c, d, in[12],  3);
    MD4STEP(F1, d, a, b, c, in[13],  7);
    MD4STEP(F1, c, d, a, b, in[14], 11);
    MD4STEP(F1, b, c, d, a, in[15], 19);
                                
    MD4STEP(F2, a, b, c, d, in[ 0] + 0x5a827999,  3);
    MD4STEP(F2, d, a, b, c, in[ 4] + 0x5a827999,  5);
    MD4STEP(F2, c, d, a, b, in[ 8] + 0x5a827999,  9);
    MD4STEP(F2, b, c, d, a, in[12] + 0x5a827999, 13);
    MD4STEP(F2, a, b, c, d, in[ 1] + 0x5a827999,  3);
    MD4STEP(F2, d, a, b, c, in[ 5] + 0x5a827999,  5);
    MD4STEP(F2, c, d, a, b, in[ 9] + 0x5a827999,  9);
    MD4STEP(F2, b, c, d, a, in[13] + 0x5a827999, 13);
    MD4STEP(F2, a, b, c, d, in[ 2] + 0x5a827999,  3);
    MD4STEP(F2, d, a, b, c, in[ 6] + 0x5a827999,  5);
    MD4STEP(F2, c, d, a, b, in[10] + 0x5a827999,  9);
    MD4STEP(F2, b, c, d, a, in[14] + 0x5a827999, 13);
    MD4STEP(F2, a, b, c, d, in[ 3] + 0x5a827999,  3);
    MD4STEP(F2, d, a, b, c, in[ 7] + 0x5a827999,  5);
    MD4STEP(F2, c, d, a, b, in[11] + 0x5a827999,  9);
    MD4STEP(F2, b, c, d, a, in[15] + 0x5a827999, 13);
                                
    MD4STEP(F3, a, b, c, d, in[ 0] + 0x6ed9eba1,  3);
    MD4STEP(F3, d, a, b, c, in[ 8] + 0x6ed9eba1,  9);
    MD4STEP(F3, c, d, a, b, in[ 4] + 0x6ed9eba1, 11);
    MD4STEP(F3, b, c, d, a, in[12] + 0x6ed9eba1, 15);
    MD4STEP(F3, a, b, c, d, in[ 2] + 0x6ed9eba1,  3);
    MD4STEP(F3, d, a, b, c, in[10] + 0x6ed9eba1,  9);
    MD4STEP(F3, c, d, a, b, in[ 6] + 0x6ed9eba1, 11);
    MD4STEP(F3, b, c, d, a, in[14] + 0x6ed9eba1, 15);
    MD4STEP(F3, a, b, c, d, in[ 1] + 0x6ed9eba1,  3);
    MD4STEP(F3, d, a, b, c, in[ 9] + 0x6ed9eba1,  9);
    MD4STEP(F3, c, d, a, b, in[ 5] + 0x6ed9eba1, 11);
    MD4STEP(F3, b, c, d, a, in[13] + 0x6ed9eba1, 15);
    MD4STEP(F3, a, b, c, d, in[ 3] + 0x6ed9eba1,  3);
    MD4STEP(F3, d, a, b, c, in[11] + 0x6ed9eba1,  9);
    MD4STEP(F3, c, d, a, b, in[ 7] + 0x6ed9eba1, 11);
    MD4STEP(F3, b, c, d, a, in[15] + 0x6ed9eba1, 15);
                                
    state[0] += a;
    state[1] += b;
    state[2] += c;
    state[3] += d;
}


// ----------------------------------------------------------------------


