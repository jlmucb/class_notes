//
//      usertpm.h  Header File 
//      
//      Entropy sources from TPM using TBS on Vista
//      (c) 2007, John L. Manferdelli
//


// ------------------------------------------------------------------------------------


#ifndef _USERTPM_H_
#define _USERTPM_H_

#include "rng.h"
#include "tbs.h"                        // note this uses a modified tbs.h since context params causes a problem

#define TPM_RAND_BUF_SIZE 1024
class TpmEntropy {
public:
    int                     m_iTotalDataSize;
    byte                    m_rgTotalData[TPM_RAND_BUF_SIZE];
    TBS_HCONTEXT            m_hContext;
    TBS_CONTEXT_PARAMS      m_ctxParams;

    TpmEntropy();
    ~TpmEntropy();
    bool Init();
    int  Collect(int maxBytes, byte* peBytes, int* iEntEstimate);   // bytes returned
    void prettyPrint();
};


#endif


// ------------------------------------------------------------------------------------


