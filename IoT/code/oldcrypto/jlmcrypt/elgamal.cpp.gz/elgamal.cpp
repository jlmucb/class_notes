#include <stdio.h>
#include <io.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <time.h>
#include <string.h>

#ifdef MSC
#include "disable.h"
#endif

#include "smallnumber.h"
#include "bignum.h"
#include "elgamal.h"
#ifdef   USEGMP
#include "gmpxx.h"
#include "gmp.h"
#include "gmpSupport.h"
#endif

//
//  elgamal.cpp
//  (c), 2007, John L. Manferdelli


// For Debug: #define PRINTINTERMEDIATE


// ---------------------------------------------------------------------------------------


bool BabyElGamal::PublicInit(u32 uP, u32 uG, u32 uGpowA)
{
    m_uP= uP;
    m_uG= uG;
    m_uGpowA= uGpowA;

    m_fPublicReady= true;
    m_fPrivateReady= false;
    return true;
}


bool BabyElGamal::PrivateInit(u32 uP, u32 uG, u32 uGpowA, u32 uA)
{
    m_uP= uP;
    m_uG= uG;
    m_uGpowA= uGpowA;
    m_uA= uA;

    m_fPublicReady= true;
    m_fPrivateReady= true;
    return true;
}


int BabyElGamal::Encrypt(u32 b, u32* pt, u32* ct1, u32* ctB)
{
    u32 B;
    u32 AB;
    u64 t;

    B= smModExp(m_uP, b, m_uG);
    AB= smModExp(m_uP, b, m_uGpowA);
    t= (u64) AB;
    t*= (u64) (*pt); 
    t%= m_uP;
    *ct1= (u32) t;
    *ctB= B;
    return 32;
}


int BabyElGamal::Decrypt(u32* ct1, u32* ctB, u32* pt)
{
    u32 B= *ctB;
    u32 AB;
    u64 t;

    AB= smModExp(m_uP, m_uA, B);
    t= (u32) smInvert(m_uP, AB);
    t*= (u64) (*ct1);
    t%= m_uP;
    *pt= (u32) t;
    return 32;
}


void BabyElGamal::CleanKeys()
{
    m_uP= 0;
    m_uG= 0;
    m_uGpowA= 0;
    m_uA= 0;
}


// ---------------------------------------------------------------------------------------


bool ElGamal::PublicInit(int iBitSizeP, bNum bnP, int iBitSizeG, bNum bnG, 
                          int iBitSizeGpowA, bNum bnGpowA)
{
    m_iBitSizeP= iBitSizeP; 
    m_bnP= bnP;
    m_iBitSizeG= iBitSizeG;
    m_bnG= bnG;
    m_iBitSizeGpowA= iBitSizeGpowA;
    m_bnGpowA= bnGpowA;
    m_iBitSizeA= 0;
    m_bnA= NULL;

#ifdef USEGMP
    mpz_init(m_bigP);
    mpz_init(m_bigG);
    mpz_init(m_bigGpowA);

    internaltoGMPConvert(m_bnP, m_bigP);
    internaltoGMPConvert(m_bnG, m_bigG);
    internaltoGMPConvert(m_bnGpowA, m_bigGpowA);
#else
#endif

    m_fPublicReady= true;
    m_fPrivateReady= false;
    return true;
}


bool ElGamal::PrivateInit(int iBitSizeP, bNum bnP, int iBitSizeG, bNum bnG, int iBitSizeGpowA,
                           bNum bnGpowA, int iBitSizeA, bNum bnA)
{
    m_iBitSizeP= iBitSizeP; 
    m_bnP= bnP;
    m_iBitSizeG= iBitSizeG;
    m_bnG= bnG;
    m_iBitSizeGpowA= iBitSizeGpowA;
    m_bnGpowA= bnGpowA;
    m_iBitSizeA= iBitSizeA;
    m_bnA= bnA;

#ifdef USEGMP
    mpz_init(m_bigP);
    mpz_init(m_bigG);
    mpz_init(m_bigGpowA);
    mpz_init(m_bigA);

    internaltoGMPConvert(m_bnP, m_bigP);
    internaltoGMPConvert(m_bnG, m_bigG);
    internaltoGMPConvert(m_bnGpowA, m_bigGpowA);
    internaltoGMPConvert(m_bnA, m_bigA);
#else
#endif

    m_fPublicReady= true;
    m_fPrivateReady= false;
    return true;
}


int ElGamal::Encrypt(bNum bnb, bNum pt, bNum ct1, bNum ctB)
{
#ifdef USEGMP
    mpz_t   bigpt;	mpz_init(bigpt);
    mpz_t   bigct1;	mpz_init(bigct1);
    mpz_t   bigctB;	mpz_init(bigctB);
    mpz_t   bigAB;	mpz_init(bigAB);
    mpz_t   bigb;	mpz_init(bigb);

    internaltoGMPConvert(pt, bigpt);
    internaltoGMPConvert(bnb, bigb);
    mpz_powm(bigctB, m_bigG, bigb, m_bigP);
    mpz_powm(bigAB, m_bigGpowA, bigb, m_bigP);
    mpz_mul(bigct1, bigpt, bigAB);
    mpz_mod (bigct1, bigct1, m_bigP);
    GMPtointernalConvert(bigct1, ct1);
    GMPtointernalConvert(bigctB, ctB);

    mpz_clear(bigpt);
    mpz_clear(bigct1);
    mpz_clear(bigctB);
    mpz_clear(bigAB);
    mpz_clear(bigctB);
#else
#endif

    return true;
}


int ElGamal::Decrypt(bNum ct1, bNum ctB, bNum pt)
{
#ifdef USEGMP
    mpz_t   bigpt;	mpz_init(bigpt);
    mpz_t   bigct1;	mpz_init(bigct1);
    mpz_t   bigctB;	mpz_init(bigctB);
    mpz_t   bigAB;	mpz_init(bigAB);
    mpz_t   bigABI;	mpz_init(bigABI);
    mpz_t   bigb;	mpz_init(bigb);

    internaltoGMPConvert(ct1, bigct1);
    internaltoGMPConvert(ctB, bigctB);
    mpz_powm(bigAB, bigctB, m_bigA, m_bigP);
    mpz_invert(bigABI, bigAB, m_bigP);
    mpz_mul(bigpt, bigct1, bigABI);
    mpz_mod (bigpt, bigpt, m_bigP);
    GMPtointernalConvert(bigpt, pt);

    mpz_clear(bigpt);
    mpz_clear(bigct1);
    mpz_clear(bigctB);
    mpz_clear(bigAB);
    mpz_clear(bigABI);
    mpz_clear(bigb);
#else
#endif

    return true;
}


void ElGamal::CleanKeys()
{
#ifdef USEGMP
    mpz_clear(m_bigP);
    mpz_clear(m_bigG);
    mpz_clear(m_bigA);
    mpz_clear(m_bigGpowA);
#else
    // clear bnA, etc
#endif

    return;
}


bool ElGamal::PublicInit(int iBitSizeP, mpz_t& bigP, mpz_t& bigG, mpz_t& bigGpowA)
{
    m_iBitSizeP= iBitSizeP; 

    mpz_init(m_bigP);
    mpz_init(m_bigG);
    mpz_init(m_bigGpowA);

    mpz_set(m_bigP, bigP);
    mpz_set(m_bigG, bigG);
    mpz_set(m_bigGpowA, bigGpowA);

    m_fPublicReady= true;
    m_fPrivateReady= false;
    return true;
}


bool ElGamal::PrivateInit(int iBitSizeP, mpz_t& bigP, mpz_t& bigG, mpz_t& bigGpowA, mpz_t& bigA)
{
    m_iBitSizeP= iBitSizeP; 

    mpz_init(m_bigP);
    mpz_init(m_bigG);
    mpz_init(m_bigGpowA);
    mpz_init(m_bigA);

    mpz_set(m_bigP, bigP);
    mpz_set(m_bigG, bigG);
    mpz_set(m_bigA, bigA);
    mpz_powm(m_bigGpowA, bigG, bigA, m_bigP);

#ifdef PRINTINTERMEDIATE
    char* szP= mpz_get_str(NULL, 10, m_bigP);
    printf("\n\nEG Init\nP: %s\n", szP);
    char* szG= mpz_get_str(NULL, 10, m_bigG);
    printf("G: %s\n", szG);
    char* szA= mpz_get_str(NULL, 10, m_bigA);
    printf("A: %s\n", szA);
    char* szGpowA= mpz_get_str(NULL, 10, m_bigGpowA);
    printf("G**A: %s\n", szGpowA);
#endif
    m_fPublicReady= true;
    m_fPrivateReady= true;
    return true;
}


int ElGamal::Encrypt(mpz_t& bigb, mpz_t& bigpt, mpz_t& bigctB, mpz_t& bigct1)
{
    mpz_t   bigAB;  mpz_init(bigAB);
    mpz_t   bigt;   mpz_init(bigt);

    mpz_powm(bigctB, m_bigG, bigb, m_bigP);
    mpz_powm(bigAB, m_bigGpowA, bigb, m_bigP);
    mpz_mul(bigt, bigpt, bigAB);
    mpz_mod (bigct1, bigt, m_bigP);

#ifdef PRINTINTERMEDIATE
    char* szb= mpz_get_str(NULL, 10, bigb);
    printf("b: %s\n", szb);
    char* szpt= mpz_get_str(NULL, 10, bigpt);
    printf("pt: %s\n", szpt);
    char* szAB= mpz_get_str(NULL, 10, bigAB);
    printf("G**(AB): %s\n", szAB);
    char* szctB= mpz_get_str(NULL, 10, bigctB);
    printf("ctB: %s\n", szctB);
    char* szct1= mpz_get_str(NULL, 10, bigct1);
    printf("ct1: %s\n", szct1);
#endif

    mpz_clear(bigAB);
    mpz_clear(bigt);
    return true;
}


int ElGamal::Decrypt(mpz_t& bigctB, mpz_t& bigct1, mpz_t& bigpt)
{
    mpz_t   bigAB;	mpz_init(bigAB);
    mpz_t   bigABI;	mpz_init(bigABI);
    mpz_t   bigt;	mpz_init(bigt);

    mpz_powm(bigAB, bigctB, m_bigA, m_bigP);
    mpz_invert(bigABI, bigAB, m_bigP);
    mpz_mul(bigt, bigct1, bigABI);
    mpz_mod (bigpt, bigt, m_bigP);

#ifdef PRINTINTERMEDIATE
    char* szAB= mpz_get_str(NULL, 10, bigAB);
    printf("G**(AB): %s\n", szAB);
    char* szABI= mpz_get_str(NULL, 10, bigABI);
    printf("G**(-AB): %s\n", szABI);
    char* szctB= mpz_get_str(NULL, 10, bigctB);
    printf("ctB: %s\n", szctB);
    char* szct1= mpz_get_str(NULL, 10, bigct1);
    printf("ct1: %s\n", szct1);
    char* szpt= mpz_get_str(NULL, 10, bigpt);
    printf("pt: %s\n", szpt);

    mpz_t   bigt2;  mpz_init(bigt2);
    mpz_t   bigt3;  mpz_init(bigt3);
    mpz_mul(bigt2, bigABI, bigAB);
    mpz_mod(bigt3, bigt2, m_bigP);
    char* sztest= mpz_get_str(NULL, 10, bigt3);
    printf("AB*(ABI): %s\n", sztest);
#endif
    mpz_clear(bigAB);
    mpz_clear(bigABI);
    mpz_clear(bigt);
    return true;
}


// ---------------------------------------------------------------------------------------


#ifdef TEST
int main(int an, char** av)
{
    u32 p, a, b, g, A, B;
    u32 x, y1, y2, z;
    BabyElGamal oEG;

    p= 331; g=2; a= 129; b= 19;
    A= smModExp(p, a, g);
    B= smModExp(p, b, g);

    oEG.PrivateInit(p, g, A, a);
    printf("p: %d, g: %d, A: %d, a: %d, b: %d, B: %d\n", 
            oEG.m_uP, oEG.m_uG, oEG.m_uGpowA, oEG.m_uA, b, B);

    x= 75;
    oEG.Encrypt(b, &x, &y1, &y2);
    oEG.Decrypt(&y1, &y2, &z);
    printf("ElGamal: %d -> %d %d -> %d\n", x, y1, y2, z);

    return 0;
}
#endif


// ---------------------------------------------------------------------------------------

