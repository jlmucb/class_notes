#ifndef _MD4_H
#define _MD4_H_


// ----------------------------------------------------------------



#ifndef u8
typedef unsigned char u8;
typedef unsigned u32;
typedef long long unsigned u64;
#endif


#define MD4_BLOCK_LENGTH          64
#define MD4_DIGEST_LENGTH         16
#define MD4_DIGEST_STRING_LENGTH  (MD4_DIGEST_LENGTH*2 + 1)


class MD4 {
public:
    void Init();
    void Update(u8 *input, u64 len);
    void Final(u8 digest[MD4_DIGEST_LENGTH]);
    void Transform(u32 state[4], const u8 block[MD4_BLOCK_LENGTH]);
    void Pad();

    u32 state[4];                   // state
    u64 count;                      // number of bits, mod 2^64 */
    u8 buffer[MD4_BLOCK_LENGTH];    // input buffer 
};



// ----------------------------------------------------------------


#endif


