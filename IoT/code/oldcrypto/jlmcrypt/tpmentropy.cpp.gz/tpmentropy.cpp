#include <windows.h>
#include <stdio.h>
#include <io.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <time.h>
#include <string.h>
#include "tbs.h"
#include "entUtil.h"
#include "tpmentropy.h"
#ifdef MSC
#include "disable.h"
#endif


//
//      usertpm.cpp  
//
//      Entropy from TPM using TBS on Vista
//      (c) 2007, John L. Manferdelli
//


// -----------------------------------------------------------------------------------


bool OpenTpm(TBS_HCONTEXT* phContext, TBS_CONTEXT_PARAMS* pctxParams)
{
    TBS_RESULT          tr= TBS_SUCCESS;

    pctxParams->version= 1;
    tr= Tbsi_Context_Create(pctxParams, phContext);
    if(tr!=TBS_SUCCESS) {
        printf("TBS Create Context Error: %08x\n", tr);
        return false;
        }
    return true;
}


bool CloseTpm(TBS_HCONTEXT* phContext, TBS_CONTEXT_PARAMS* pctxParams)
{
    TBS_RESULT          tr= TBS_SUCCESS;

    pctxParams->version= 0;
    tr= Tbsip_Context_Close(*phContext);
    if(tr!=TBS_SUCCESS)
        return false;
    return true;
}


//
//  TPM byte ordering for GetRandom by trial and error
//
#define OFFSET_NUMBYTES 13
#define OFFSET_RANDOMBYTES 14
#define SIZEOFTPMREQUEST 14
static byte  rgRequestIn[SIZEOFTPMREQUEST]= {
        0x00, 0xc1,
        0x00, 0x00, 0x00, 0x0e,
        0x00, 0x00, 0x00, 0x46,
        0x00, 0x00, 0x00, 0x10
        };


int GetTPMEntropy(TBS_HCONTEXT* phContext, int nBytes, byte* pbData)
{
    TBS_RESULT          tr= TBS_SUCCESS;
    unsigned            uCommandResultSize= 40;
    byte                rgResults[256];
    byte*               pb= rgRequestIn+OFFSET_NUMBYTES;

    if(nBytes>240)
        return 0;
    *pb= nBytes;
    zeroMem(256, rgResults);
    tr= Tbsip_Submit_Command(*phContext, TBS_COMMAND_LOCALITY_ZERO, 
                             TBS_COMMAND_PRIORITY_NORMAL,
                             rgRequestIn, SIZEOFTPMREQUEST,
                             rgResults, &uCommandResultSize);
    if(tr!=TBS_SUCCESS) {
#ifdef TESTPRINTTPMRAND
        printf("TPM Submit Error: %08x\n", tr);
#endif
        return -1;
    }
    uCommandResultSize-= OFFSET_RANDOMBYTES;
    byteCopy(uCommandResultSize, rgResults+OFFSET_RANDOMBYTES, pbData);
    return (int) uCommandResultSize;
}


// -----------------------------------------------------------------------------------


TpmEntropy::TpmEntropy() 
{ 
    m_hContext= NULL;
    m_iTotalDataSize= 0;
}



TpmEntropy::~TpmEntropy() 
{ 
    if(m_hContext) {
        CloseTpm(&m_hContext, &m_ctxParams);
    }
    m_iTotalDataSize= 0;
    m_hContext= NULL;
}



bool TpmEntropy::Init()
{
    return OpenTpm(&m_hContext, &m_ctxParams);
}


int TpmEntropy::Collect (int maxBytes, byte* peBytes, int* iEntEstimate)
{
    int iRet= GetTPMEntropy(&m_hContext, maxBytes, m_rgTotalData);
    if(iRet<=0)
        return iRet;
    byteCopy(iRet, m_rgTotalData, peBytes);
    m_iTotalDataSize= iRet;
    *iEntEstimate= iRet*8;
    return iRet;
}


void TpmEntropy::prettyPrint()
{
    printf("\n%d Random Bytes from TPM: ", m_iTotalDataSize);
    prettyPrintBuffer(m_iTotalDataSize, m_rgTotalData);
}


// -----------------------------------------------------------------------------------


TpmEntropy       g_oTpmEntropy;
EntropySource    g_oTpmEntropySource;


bool TpmInitFunction() 
{
    if(g_oTpmEntropySource.m_fInitialized)
        return true;
    g_oTpmEntropySource.m_fInitialized= g_oTpmEntropy.Init();
    return g_oTpmEntropySource.m_fInitialized;
}


int TpmCollectFunction (int maxBytes, byte* peBytes, int* iEntEstimate)
{
    return g_oTpmEntropy.Collect(maxBytes, peBytes, iEntEstimate);
}


bool InitTpmSourceEntropy()
{
    if(!g_oTpmEntropySource.m_fInitialized) {
        if(!g_oTpmEntropySource.Init(ENTROPYSOURCETYPEGENERIC, 1024,
                                         TpmInitFunction, TpmCollectFunction))
            return false;
        if(!(*g_oTpmEntropySource.m_ptInitFunction)())
            return false;
    }
    return true;
}


bool GetTpmSourceEntropy(int inumBits, byte* rgBuf, char* szOutFile)
{
    int         iEntEstimate= 0;
    extern bool DumpEntropy(int iEntEstimate, int iNumBytes, byte* rgBuf, char* szOutFile);

    if(!g_oTpmEntropySource.m_fInitialized) {
        return false;
    }

    int iNumBytesRet= g_oTpmEntropySource.Collect((inumBits+7)/8, rgBuf, &iEntEstimate);
    bool fRet= true;
    if(szOutFile)
        fRet= DumpEntropy(iEntEstimate, iNumBytesRet, rgBuf, szOutFile);
    if(fRet)
        printf("File %s, %d bits of estimated entropy in %d present\n", szOutFile, 
                    iEntEstimate, iNumBytesRet);
    return fRet;
}


bool TpmTest()
{
    TpmEntropy oTpmEnt;
    byte rgTest[128];
    int iEnt= 0;

    if(!oTpmEnt.Init())
        return false;
    oTpmEnt.Collect(16, rgTest, &iEnt);
    oTpmEnt.prettyPrint();
    return true;
}


// -----------------------------------------------------------------------------------


