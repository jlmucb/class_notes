

// ----------------------------------------------------------------


#ifndef _MD4_H
#define _MD4_H_

#ifndef u8
typedef unsigned char u8;
typedef unsigned u32;
typedef long long unsigned u64;
#endif


#define MD4_BLOCK_LENGTH          64


class MD5 {
public:
    void Init();
    void Update(u8* buf, unsigned len);
    void Final(u8 digest[16]);
    void byteReverse(u8* buf, unsigned longs);
    void Transform(u32 buf[4], u32 in[16]);
    u32 buf[4];
    u32 bits[2];
    u8 in[64];
    };

#endif                


// ----------------------------------------------------------------


