//
//  Module Name: elgamal.h
//
//  Copyright 2007, John L. Manferdellil
//


// ------------------------------------------------------------------------


#ifndef __ELGAMAL_H
#define __ELGAMAL_H

#include "bignum.h"

#ifdef USEGMP
#include "gmpxx.h"
#include "gmp.h"
#endif


class ElGamal {
public:
    bool    m_fPublicReady;
    bool    m_fPrivateReady;

    int     m_iBitSizeP; 
    bNum    m_bnP;

    int     m_iBitSizeG; 
    bNum    m_bnG;

    int     m_iBitSizeGpowA; 
    bNum    m_bnGpowA;

    int     m_iBitSizeA; 
    bNum    m_bnA;

#ifdef USEGMP
    mpz_t   m_bigP;
    mpz_t   m_bigG;
    mpz_t   m_bigGpowA;
    mpz_t   m_bigA;
#endif


    ElGamal() {m_fPublicReady= false; m_fPrivateReady= false;};
    ~ElGamal() {};

    bool    PublicInit(int iBitSizeP, bNum bnP, int iBitSizeG, bNum bnG, int iBitSizeGpowA,
                        bNum bnGpowA);
    bool    PrivateInit(int iBitSizeP, bNum bnP, int iBitSizeG, bNum bnG, int iBitSizeGpowA,
                        bNum bnGpowA, int iBitSizeA, bNum bnA);
    int     Encrypt(bNum b, bNum pt, bNum ct1, bNum ctB);
    int     Decrypt(bNum ct1, bNum ctB, bNum pt);
#ifdef USEGMP
    bool    PublicInit(int iBitSizeP, mpz_t& bigP, mpz_t& bigG, mpz_t& bigGpowA);
    bool    PrivateInit(int iBitSizeP, mpz_t& bigP, mpz_t& bigG,
                        mpz_t& bigGpowA, mpz_t& bigA);
    int     Encrypt(mpz_t& bigb, mpz_t& bigpt, mpz_t& bigct1, mpz_t& bigctB);
    int     Decrypt(mpz_t& bigct1, mpz_t& bigctB, mpz_t& bigpt);
#endif

    void    CleanKeys();
};


class BabyElGamal {
public:
    bool    m_fPublicReady;
    bool    m_fPrivateReady;

    u32     m_uP;
    u32     m_uG;
    u32     m_uA;
    u32     m_uGpowA;

    BabyElGamal() {m_fPublicReady= false; m_fPrivateReady= false;};
    ~BabyElGamal() {};

    bool    PublicInit(u32 uP, u32 uG, u32 uGpowA);
    bool    PrivateInit( u32 uP, u32 uG, u32 uGpowA, u32 uA);
    int     Encrypt(u32 b, u32* pt, u32* ct1, u32* ctB);
    int     Decrypt(u32* ct1, u32* ctB, u32* pt);
    void    CleanKeys();
};
#endif


// ------------------------------------------------------------------------

