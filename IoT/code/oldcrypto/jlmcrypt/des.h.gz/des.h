//
//  Module Name: des.h
//
//  This module contains the low-level DES encryption routines.
//  Derived from public domain sources and modified for usage in the NT
//  programming environment.
//
//      Modified by John Manferdelli from a public domain version by:
//          Phil Karn


// ------------------------------------------------------------------------


#ifndef __DES_H
#define __DES_H


#ifndef u8
typedef unsigned char           u8;      
typedef unsigned short          u16;     
typedef unsigned                u32;
typedef unsigned long long      u64;
#endif


class des {
public:
    des() {};
    ~des() {};

    long    sp[8][64];
    u8      iperm[16][16][8];
    u8      fperm[16][16][8];
    u8      kn[16][8];
    int     desmode;

    void    spinit();
    void    desinit(int mode);
    void    setkey(u8* key);
    void    round(int num, unsigned* block);
    long    f(unsigned r, u8 subkey[8]);
    void    perminit(u8 perm[16][16][8], u8 p[64]);
    void    permute(u8* inblock, u8 perm[16][16][8], u8* outblock);

    bool    Init(u8 cipherKey[], int keyBits);
    void    Encrypt(u8 pt[8], u8 ct[8]);
    void    Decrypt(u8 ct[8], u8 pt[8]);
    void    CleanKeys();
};

#endif


// ------------------------------------------------------------------------

