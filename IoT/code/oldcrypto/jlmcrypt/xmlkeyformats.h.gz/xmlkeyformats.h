#include "rng.h"
#include "jlmUtil.h"


// ---------------------------------------------------------------------------------------


#ifndef _XMLKEYFORMATS_H
#define _XMLKEYFORMATS_H

int WriteXmlKey(keyStruct* pKey, int iBufSize, char* szBuf);
bool ReadXmlKey(char* szXmlInput, keyStruct* pKey);

#endif


// ---------------------------------------------------------------------------------------


