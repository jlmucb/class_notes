#include <stdio.h>
#include <io.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <time.h>
#include <string.h>


// bool.cpp

#define INBUFSIZE  2048
#define OUTBUFSIZE  2048
int     iInSize= 0;
int     iOutSize= 0;
int     iCurinPos= 0;
char    rgoutBuf[INBUFSIZE];
char    rginBuf[OUTBUFSIZE];
int     iTotalBytes= 0;
char    rglineBuf[INBUFSIZE];

#define READFLAGS  _O_RDONLY | _O_BINARY
#define CREATFLAGS _O_CREAT | _O_BINARY

#define BYTEFORMAT  1
#define SHORTFORMAT 2
#define WORDFORMAT  3
#define LONGFORMAT  4


int g_iFormat= BYTEFORMAT;



// --------------------------------------------------------------------- 


inline bool whitespace(char b)
{
    return(b==' ' || b=='\t' || b=='\r' || b=='\n');
}


inline bool validHex(char b)
{
    if(b>='0' && b<='9')
        return true;
    if(b>='a' && b<='f')
        return true;
    if(b>='A' && b<='F')
        return true;
    return false;
}


int getline(int inFile)
{
    int     iLineSize= 0;

    for(;;) {
        if(iCurinPos>=iInSize) {
            iInSize= read(inFile, rginBuf, INBUFSIZE);
            if(iInSize<=0)
                return -1;
            iCurinPos= 0;
        }
        rglineBuf[iLineSize]= rginBuf[iCurinPos++];
        iLineSize++;
        if(rglineBuf[iLineSize-1]=='\n')
            return iLineSize;
    }
}


int readline(int inFile, int outFile)
{
    int                 i, k;
    char                a, b;
    int                 iLineSize= getline(inFile);
    unsigned            num;
    unsigned long long  lnum;

    if(iLineSize<=0)
        return iLineSize;

    rglineBuf[iLineSize]= '\0';
    printf("Line: %s", rglineBuf);

    for(i=0; i<iLineSize;) {
        // get first non-whitespace
        while(i<iLineSize) {
            a= rglineBuf[i];
            if(!whitespace(a))
                break;
            i++;
        }
        if(a=='#')
            return i;
        if(i>=iLineSize)
            break;
        b= rglineBuf[i+1];

        if(a=='0' && b=='x') {  
            // got a number, process it
            for(k=(i+2);k<iLineSize; k++) {
                a= rglineBuf[k];
                if(!validHex(a))
                    break;
            }
            // got range for number
            if(g_iFormat==BYTEFORMAT) {
                sscanf(&rglineBuf[i], "%x", &num);
                i= k;
                if(iOutSize>=OUTBUFSIZE) {
                    write(outFile, rgoutBuf, iOutSize);
                    iTotalBytes+= iOutSize;
                    iOutSize= 0;
                }
                rgoutBuf[iOutSize++]= (unsigned char) num;
            }
            else if(g_iFormat==SHORTFORMAT) {
                sscanf(&rglineBuf[i], "%x", &num);
                i= k;
                if(iOutSize>=OUTBUFSIZE) {
                    write(outFile, rgoutBuf, iOutSize);
                    iTotalBytes+= iOutSize;
                    iOutSize= 0;
                }
                *(short unsigned*) (&rgoutBuf[iOutSize])= (unsigned short) num;
                iOutSize+= 2;
            }
            else if(g_iFormat==WORDFORMAT) {
                sscanf(&rglineBuf[i], "%x", &num);
                i= k;
                if(iOutSize>=OUTBUFSIZE) {
                    write(outFile, rgoutBuf, iOutSize);
                    iTotalBytes+= iOutSize;
                    iOutSize= 0;
                }
                *(unsigned*) (&rgoutBuf[iOutSize])= num;
                iOutSize+= 4;
            }
            else if(g_iFormat==LONGFORMAT) {
                sscanf(&rglineBuf[i], "%Lx", &lnum);
                i= k;
                if(iOutSize>=OUTBUFSIZE) {
                    write(outFile, rgoutBuf, iOutSize);
                    iTotalBytes+= iOutSize;
                    iOutSize= 0;
                }
                *(unsigned long long *) (&rgoutBuf[iOutSize])= lnum;
                iOutSize+= 8;
            }
            continue;
        }
        i++;
    }

    return iLineSize;
}


int main(int an, char** av)

{
        int iIn, iOut;
        char* szinFile=  NULL;
        char* szoutFile= NULL;

        if(an<3) {
            printf("prepbool [-x1|-x2|-x4|-x8] inFile outFile\n");
            return 1;
        }

        if(an>3 && strcmp(av[1],"-x1")==0) {
            g_iFormat= BYTEFORMAT;
            szinFile= av[2];
            szoutFile= av[3];
        }
        else if(an>3 && strcmp(av[1],"-x2")==0) {
            g_iFormat= SHORTFORMAT;
            szinFile= av[2];
            szoutFile= av[3];
        }
        else if(an>3 && strcmp(av[1],"-x4")==0) {
            g_iFormat= WORDFORMAT;
            szinFile= av[2];
            szoutFile= av[3];
        }
        else if(an>3 && strcmp(av[1],"-x8")==0) {
            g_iFormat= LONGFORMAT;
            szinFile= av[2];
            szoutFile= av[3];
        }
        else {
            szinFile= av[1];
            szoutFile= av[2];
        }

        if((iIn=_open(szinFile, READFLAGS))<0) {
                printf("Cant open %s\n", av[1]);
                return 1;
                }
        if((iOut=_creat(szoutFile, CREATFLAGS))<0) {
                printf("Cant creat %s\n", av[2]);
                return 1;
                }
        _setmode(iIn, _O_BINARY);
        _setmode(iOut, _O_BINARY);

        while(readline(iIn, iOut)>=0);

        if(iOutSize>0) {
            write(iOut, rgoutBuf, iOutSize);
            iTotalBytes+= iOutSize;
            }

        close(iIn);
        close(iOut);
        printf("%d output bytes\n", iTotalBytes);

        return 0;
}


// --------------------------------------------------------------------- 


