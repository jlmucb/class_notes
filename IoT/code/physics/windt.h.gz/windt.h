

typedef long int Int;
typedef char Char;
typedef double Double;
typedef int Short;
typedef long Long;

#define PI 3.141592653589793


