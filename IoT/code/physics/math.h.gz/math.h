#define FABS

#define PI 3.141592653589793
#define LN2 0.693147180559945309417232121458

double sqrt(), sin(), cos(), asin(), acos(), tan(), atan(), ln(), exp();

#define ERROR 0

