#define LN2 0.693147180559945309417232121458

double sqrt(), sin(), cos(), asin(), acos(), tan(), atan(), ln(), exp();

#define ERROR 0


typedef long int Int;
typedef char Char;
typedef double Double;
typedef int Short;
typedef long Long;
typedef long unsigned Unsigned;

#define PI 3.141592653589793


